gta3.std.sprites
=========================================================================
 + __Author__:   LINK/2012 (<dma_2012@hotmail.com>)
 + __Priority__: 51
 + __Game__: III, Vice City, San Andreas

*************************************************************************

__Description__:
 This plugin is responsible for handling texture dictionaries that would go to the *txd/* folder, essentially script textures.
    
__Usage__:
 Those sprite texture dictionaries should be inside a *txd/* folder (e.g. *modloader/my splash/txd/loadscs.txd*)

